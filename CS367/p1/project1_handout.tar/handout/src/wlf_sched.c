/* This is the only file you will be editing.
 * - wlf_sched.c (Wlf Scheduler Library Code)
 * - Copyright of Starter Code: Prof. Kevin Andrea, George Mason University. All Rights Reserved
 * - Copyright of Student Code: You!  
 * - Copyright of ASCII Art: Modified from an uncredited author's work:
 * -- https://www.asciiart.eu/animals/wolves
 * - Restrictions on Student Code: Do not post your code on any public site (eg. Github).
 * -- Feel free to post your code on a PRIVATE Github and give interviewers access to it.
 * -- You are liable for the protection of your code from others.
 * - Date: Jan 2025
 */

/* CS367 Project 1, Spring Semester, 2025
 * Fill in your Name, GNumber, and Section Number in the following comment fields
 * Name:  
 * GNumber:  G
 * Section Number: CS367-00_             (Replace the _ with your section number)
 */

/* wlf CPU Scheduling Library
                     .
                    / V\
                  / `  /
                 <<   |
                 /    |
               /      |
             /        |
           /    \  \ /
          (      ) | |
  ________|   _/_  | |
<__________\______)\__)
*/
 
/* Standard Library Includes */
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <string.h>
/* Unix System Includes */
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <pthread.h>
#include <sched.h>
/* DO NOT CHANGE THE FOLLOWING INCLUDES - Local Includes 
 * If you change these, it will not build on Zeus with the Makefile
 * If you change these, it will not run in the grader
 */
#include "wlf_sched.h"
#include "strawhat_scheduler.h"
#include "strawhat_support.h"
#include "strawhat_process.h"
/* DO NOT CHANGE ABOVE INCLUDES - Local Includes */

/* Feel free to create any definitions or constants you like! */

/* Feel free to create any helper functions you like! */

/*** Wlf Library API Functions to Complete ***/

/* Initializes the Wlf_schedule_s Struct and all of the Wlf_queue_s Structs
 * Follow the project documentation for this function.
 * Returns a pointer to the new Wlf_schedule_s or NULL on any error.
 * - Hint: What does malloc return on an error?
 */
Wlf_schedule_s *wlf_initialize() {
  return NULL; /* Replace This Line with your Code */
}

/* Allocate and Initialize a new Wlf_process_s with the given information.
 * - Malloc and copy the command string, don't just assign it!
 * Follow the project documentation for this function.
 * - You may assume all arguments within data are Legal and Correct for this Function Only
 * Returns a pointer to the Wlf_process_s on success or a NULL on any error.
 */
Wlf_process_s *wlf_create(Wlf_create_data_s *data) {
  return NULL; /* Replace This Line with your Code */
}

/* Inserts a process into the appropriate Ready Queue (singly linked list).
 * Follow the project documentation for this function.
 * - Do not create a new process to insert, insert the SAME process passed in.
 * Returns a 0 on success or a -1 on any error.
 */
int wlf_enqueue(Wlf_schedule_s *schedule, Wlf_process_s *process) {
  return -2; /* Replace This Line with your Code */
}

/* Returns the number of items in a given Wlf Queue (singly linked list).
 * Follow the project documentation for this function.
 * Returns the number of processes in the list or -1 on any errors.
 */
int wlf_count(Wlf_queue_s *queue) {
  return -2; /* Replace This Line with your Code */
}

/* Selects the best process to run from the Ready Queues (singly linked list).
 * Follow the project documentation for this function.
 * Returns a pointer to the process selected or NULL if none available or on any errors.
 * - Do not create a new process to return, return a pointer to the SAME process selected.
 * - Return NULL if the ready queues were both empty OR if there were any errors.
 */
Wlf_process_s *wlf_select(Wlf_schedule_s *schedule) {
  return NULL; /* Replace This Line with your Code */
}

/* Ages all Process nodes in the Ready Queue - Normal and Promotes any that are Starving.
 * If the Ready Queue - Normal is empty, return 0.  (Success if nothing to do)
 * Follow the specification for this function.
 * Returns a 0 on success or a -1 on any error.
 */
int wlf_promote(Wlf_schedule_s *schedule) {
  return -2; /* Replace This Line with your Code */
}

/* This is called when a process exits normally that was just Running.
 * Put the given node into the Terminated Queue and set the Exit Code 
 * - Do not create a new process to insert, insert the SAME process passed in.
 * Follow the project documentation for this function.
 * Returns a 0 on success or a -1 on any error.
 */
int wlf_exited(Wlf_schedule_s *schedule, Wlf_process_s *process, int exit_code) {
  return -2; /* Replace This Line with your Code */
}

/* This is called when the OS terminates a process early. 
 * - This will either be in your Ready Queue - High or Ready Queue - Normal.
 * - The difference with wlf_exited is that this process is in one of your Queues already.
 * Remove the process with matching pid from either Ready Queue and add the Exit Code to it.
 * - You have to check both since it could be in either queue.
 * Follow the project documentation for this function.
 * Returns a 0 on success or a -1 on any error.
 */
int wlf_killed(Wlf_schedule_s *schedule, pid_t pid, int exit_code) {
  return -2; /* Replace This Line with your Code */
}

/* This is called when StrawHat reaps a Terminated (Defunct) Process.  (reap command).
 * Remove and free the process with matching pid from the Termainated Queue.
 * Follow the specification for this function.
 * Returns the exit_code on success or a -1 on any error (such as process not found).
 */
int wlf_reap(Wlf_schedule_s *schedule, pid_t pid) {
  return -2; /* Replace This Line with your Code */
}

/* Gets the exit code from a terminated process.
 * (All Linux exit codes are between 0 and 255)
 * Follow the project documentation for this function.
 * Returns the exit code if the process is terminated.
 * If the process is not terminated, return -1.
 */
int wlf_get_ec(Wlf_process_s *process) {
  return -2; /* Replace This Line with your Code */
}

/* Frees all allocated memory in the Wlf_schedule_s, all of the Queues, and all of their Nodes.
 * Follow the project documentation for this function.
 * Returns void.
 */
void wlf_cleanup(Wlf_schedule_s *schedule) {
  return; /* Replace This Line with your Code */
}